const express = require("express")
const colors = require("colors")
const morgan = require("morgan")
const dotenv = require("dotenv");
const mySqlPool = require("./config/db");

//configure dotenv
dotenv.config();

//rest Object
const app = express()

//middlewares
app.use(express.json())
app.use(morgan("dev"));

//routes
app.use('/api/v1/student', require("./routes/studentsRoutes"));
app.get('/test', (req,res) => {
    res.status(200).send('<h1>CRUD API using Node.js, Express, MySQL<h1>')
})

//port
const port = process.env.port || 8080;

//conditionally listen
mySqlPool
    .query('SELECT 1')
    .then(() => { 

    //MYSQL
    console.log('MySQL DB Connected'.bgCyan.white)

    //listen 
    app.listen(port, () => {
        console.log(`Server Running On Port ${process.env.port}`.bgRed.white);
    });

}).catch((error) => {
    console.log(error);
});

