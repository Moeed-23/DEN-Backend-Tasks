module.exports = (app) => {
    const blogController = require('../controllers/blogController');
  
    // Create a new Post
    app.post('/posts', blogController.createPost);
  
    // Retrieve all Posts
    app.get('/posts', blogController.getAllPosts);
  
    // Retrieve a single Post by ID
    app.get('/posts/:id', blogController.getPostById);
  
    // Update a Post by ID
    app.put('/posts/:id', blogController.updatePost);
  
    // Delete a Post by ID
    app.delete('/posts/:id', blogController.deletePost);
  
    // Add a comment to a Post
    app.post('/posts/:id/comments', blogController.addComment);
  };
  