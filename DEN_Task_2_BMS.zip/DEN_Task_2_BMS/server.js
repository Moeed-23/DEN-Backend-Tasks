const express = require('express');
const app = express();
const morgan = require("morgan")

const PORT = process.env.PORT || 3080;

app.use(express.json())
app.use(morgan("dev"));

console.log('MySQL DB Connected')

app.use('/api/v2/blogg', require("./routes/blogRoutes"));

app.get('/blog', (req, res) => {
    res.send('Blog Management System is running');
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
