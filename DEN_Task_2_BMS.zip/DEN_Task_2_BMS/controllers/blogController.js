const db = require('../models');
const Post = db.Post;
const Comment = db.Comment;
const User = db.User;

exports.createPost = async (req, res) => {
   const { title, content, userId } = req.body;
   try {
     const post = await Post.create({ title, content, user_id: userId });
     res.status(201).json(post);
   } catch (error) {
     res.status(500).json({ error: error.message });
   }
};

exports.getAllPosts = async (req, res) => {
   try {
     const posts = await Post.findAll({
       include: [{ model: User, as: 'user' }, { model: Comment, as: 'comments' }]
     });
     res.status(200).json(posts);
   } catch (error) {
     res.status(500).json({ error: error.message });
   }
};

exports.getPostById = async (req, res) => {
   const { id } = req.params;
   try {
     const post = await Post.findByPk(id, {
       include: [{ model: User, as: 'user' }, { model: Comment, as: 'comments' }]
     });
     if (!post) return res.status(404).json({ error: 'Post not found' });
     res.status(200).json(post);
   } catch (error) {
     res.status(500).json({ error: error.message });
   }
};

exports.updatePost = async (req, res) => {
   const { id } = req.params;
   const { title, content } = req.body;
   try {
     const post = await Post.findByPk(id);
     if (!post) return res.status(404).json({ error: 'Post not found' });
     post.title = title;
     post.content = content;
     await post.save();
     res.status(200).json(post);
   } catch (error) {
     res.status(500).json({ error: error.message });
   }
};

exports.deletePost = async (req, res) => {
   const { id } = req.params;
   try {
     const post = await Post.findByPk(id);
     if (!post) return res.status(404).json({ error: 'Post not found' });
     await post.destroy();
     res.status(204).json();
   } catch (error) {
     res.status(500).json({ error: error.message });
   }
};

exports.addComment = async (req, res) => {
   const { content, userId } = req.body;
   const { id } = req.params;
   try {
     const comment = await Comment.create({ content, post_id: id, user_id: userId });
     res.status(201).json(comment);
   } catch (error) {
     res.status(500).json({ error: error.message });
   }
};
