const { Song, Genre } = require('../models/User');

exports.getAllSongs = async (req, res) => {
  const { title, artist, genre_id } = req.query;
  const filters = {};
  
  if (title) filters.title = { $like: `%${title}%` };
  if (artist) filters.artist = { $like: `%${artist}%` };
  if (genre_id) filters.genre_id = genre_id;

  const songs = await Song.findAll({ where: filters });
  res.json(songs);
};

exports.getGenres = async (req, res) => {
  const genres = await Genre.findAll();
  res.json(genres);
};
