const { Sequelize } = require('sequelize');

// Load environment variables from .env file
require('dotenv').config();

// Initialize Sequelize with database connection details
const sequelize = new Sequelize(
  process.env.DB_NAME,      // Database name
  process.env.DB_USER,      // MySQL username
  process.env.DB_PASSWORD,  // MySQL password
  {
    host: process.env.DB_HOST,   // MySQL host (e.g., localhost)
    dialect: 'mysql',            // Database dialect (MySQL in this case)
    logging: false,              // Set to true to log SQL queries
  }
);

// Test the connection to the database
sequelize
  .authenticate()
  .then(() => {
    console.log('Connection to the database has been established successfully.');
  })
  .catch((err) => {
    console.error('Unable to connect to the database:', err);
  });

module.exports = sequelize;
