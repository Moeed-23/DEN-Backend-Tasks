const express = require('express');
const { createPlaylist, updatePlaylist } = require('../controllers/playlistController');
const router = express.Router();

router.post('/playlists', createPlaylist);
router.put('/playlists/:id', updatePlaylist);

module.exports = router;
