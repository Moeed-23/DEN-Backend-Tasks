require('dotenv').config();  // To load environment variables from .env file
const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');  // Import your Sequelize setup

// Import routes
const userRoutes = require('./routes/userRoutes');
const songRoutes = require('./routes/songRoutes');
const playlistRoutes = require('./routes/playlistRoutes');

// Initialize the app
const app = express();

// Middleware
app.use(bodyParser.json());  // For parsing application/json
app.use(bodyParser.urlencoded({ extended: true }));  // For parsing application/x-www-form-urlencoded

// Routes
app.use('/users', userRoutes);
app.use('/songs', songRoutes);
app.use('/playlists', playlistRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Test the database connection and sync models
sequelize.sync()
  .then(() => {
    console.log('Database connected and models synced!');
  })
  .catch((err) => {
    console.error('Error connecting to the database: ', err);
  });

// Start the server
const PORT = process.env.PORT || 4080;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
