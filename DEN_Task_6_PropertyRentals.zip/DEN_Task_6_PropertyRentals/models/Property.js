// Property.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Property = sequelize.define('Property', {
  title: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.TEXT, allowNull: true },
  price: { type: DataTypes.DECIMAL, allowNull: false },
  address: { type: DataTypes.STRING, allowNull: false },
  city: { type: DataTypes.STRING, allowNull: false },
  status: { type: DataTypes.ENUM('available', 'rented'), defaultValue: 'available' },
  owner_id: { type: DataTypes.INTEGER, references: { model: User, key: 'id' } },
});

module.exports = Property;
