// Rental.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Property = require('./Property');

const Rental = sequelize.define('Rental', {
  tenant_name: { type: DataTypes.STRING, allowNull: false },
  tenant_contact: { type: DataTypes.STRING, allowNull: false },
  rental_start_date: { type: DataTypes.DATE, allowNull: false },
  rental_end_date: { type: DataTypes.DATE, allowNull: true },
  property_id: { type: DataTypes.INTEGER, references: { model: Property, key: 'id' } },
});

module.exports = Rental;
