const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
sequelize.sync();


// Import routes
const propertyRoutes = require('./routes/propertyRoutes');

const app = express();
app.use(bodyParser.json());

// Routes
app.use('/properties', propertyRoutes);

// Sync database and start the server
sequelize.sync()
  .then(() => {
    console.log('Database connected and synced');
    app.listen(5000, () => {
      console.log('Server is running on port 5000');
    });
  })
  .catch((err) => console.log('Error connecting to database', err));

  